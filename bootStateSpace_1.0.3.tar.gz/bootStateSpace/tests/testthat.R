library(testthat)
library(bootStateSpace)

test_check("bootStateSpace")
