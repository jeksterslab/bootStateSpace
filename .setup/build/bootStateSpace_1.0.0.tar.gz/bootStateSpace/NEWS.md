# bootStateSpace 1.0.0

## Patch

* Initial CRAN submission
