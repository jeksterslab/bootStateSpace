# bootStateSpace 1.0.1

## Patch

* Initial CRAN submission
