.CoefFitDynr <- function(x) {
  x@transformed.parameters
}
