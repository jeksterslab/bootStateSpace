# bootStateSpace 1.0.1.9000

## Patch

* Latest development version.
* Added the `clean` argument to the `PBSSMFixed`, `PBSSMOUFixed`, `PBSSMLinSDEFixed`, and `PBSSMVARFixed` functions.

# bootStateSpace 1.0.1

## Patch

* Initial CRAN release
